//
// Created by Aiden Pratt on 1/11/24.
//

#ifndef ASSIGNMENT1_CMDLINE_H
#define ASSIGNMENT1_CMDLINE_H

#endif //ASSIGNMENT1_CMDLINE_H

void use_arguments(int argc, char **argv);